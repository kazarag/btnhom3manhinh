package com.example.bt3manhinh;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivivity extends AppCompatActivity {
    private TextView tvKetQua;
    private Button btnTroVe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giai);

        tvKetQua = findViewById(R.id.result);
        btnTroVe = findViewById(R.id.buttonBack);

        String result = getIntent().getStringExtra("result");
        tvKetQua.setText(result);

        btnTroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
